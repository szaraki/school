#ifndef IMAGE_STRUCT_H
#define IMAGE_STRUCT_H

#include<png.h>

typedef struct {
	int width, height;
	png_byte color_type;
	png_byte bit_depth;
	png_bytep *row_pointers;
} IMAGE_DATA;


#endif