#ifndef IMAGE_H
#define IMAGE_H

#include <png.h>
#include "image_struct.h"

void merge_images( IMAGE_DATA* file_data_a);

void antialiasing( IMAGE_DATA* file_data);

void filtr( IMAGE_DATA* file_data);

void depth( IMAGE_DATA* file_data);

void delate_one_of_rgb( IMAGE_DATA* file_data);

int** histogram( IMAGE_DATA* file_data);

#endif