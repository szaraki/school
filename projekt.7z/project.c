#include "image.h"
#include "image_file.h"
#include "image_struct.h"
#include<stdio.h>
#include<stdlib.h>
#include<png.h>

int main( int argc, char *argv[] ) {
  //check arg
  if( argc ==2 && argv[1] == "-h") {
	  printf( "Program się włącza po dodaniu argumentu input_file.png  Przykład: project.o plik.png\n");
	  return 0;
  }
  if( argc != 2) {
	  printf( "Zle argumenty. Prosze skorzystac z -h aby sie dowiedziec, jak wykorzystywac program\n");
	  return 0;
  }
  //load image
  IMAGE_DATA* file_data= load_png( argv[1] );
  
  //menu
  printf("Welcome\n");
  printf( "1. Antialiasing,\n");
  printf( "2. Filr,\n");
  printf( "3. Depth,\n");
  printf( "4. Images Merge,\n");
  printf( "5. Delate a Main Color\n");
  printf( "Enter number of function: ");
  
  //input
  int selected;
  scanf( "%d", &selected);
  
  //starting programs
  switch(selected) {
	case 1:
	  antialiasing( file_data);
	  break;
	case 2:
      filtr( file_data);
	  break;
	case 3:
	  depth( file_data);
	  break;
	case 4:
      merge_images( file_data);
	  break;
	case 5: 
      delate_one_of_rgb( file_data);
	  break;
  }
  
  //save + exiting
  saving( "output.png", file_data);
  free(file_data);
  return 0;
}