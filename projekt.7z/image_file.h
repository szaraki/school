#ifndef IMAGE_FILE_H
#define IMAGE_FILE_H

#include "image_struct.h"

IMAGE_DATA* load_png( const char *filename);

void saving( const char *filename, const IMAGE_DATA* file_data);

#endif