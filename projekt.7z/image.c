#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<png.h>
#include"image_file.h"
#include "image_struct.h"

void merge_images( IMAGE_DATA* file_data_a) {
  printf( "Enter the name of another file.png: ");
  char name[100] ;
  scanf( "%s", name);
  IMAGE_DATA* file_data_b= load_png( name);
  int start_x;
  printf( "Enter starting position x: ");
  scanf( "%d", &start_x);
  int start_y;
  printf( "Enter starting position y: ");
  scanf( "%d", &start_y);
  int scale;
  printf( "Wpisz jak bardzo widoczny ma być drugi obrazek skala( 0-100): ");
  scanf( "%d", &scale);
  
  for( int y= start_y; y< file_data_a->height && y< file_data_b->height ; y++) {
    png_bytep row_a= file_data_a->row_pointers[y] ;
    png_bytep row_b= file_data_b->row_pointers[y] ;
	
    for( int x= start_x; x< file_data_a->width && x< file_data_b->width ; x++) {
      png_bytep px_a= &( row_a[( x) * 4] );
      png_bytep px_b= &( row_b[( x) * 4] );
	  
	  for( int n= 0; n< 3; n++) {
		px_a[n] =( px_a[n] *( 100-scale)+px_b[n] *( scale))/100; 
	  }
	}
  }
  free(file_data_b);
}

void antialiasing( IMAGE_DATA* file_data) {
  for( int y= 0; y< file_data->height-3; y++) {
    png_bytep row= file_data->row_pointers[y+1] ;
	
    for( int x= 0; x< file_data->width-3; x++) {
      png_bytep px= &( row[( x+1) * 4] );
	  long sum;
	  
	  for( int n=0; n<3; n++) {
		sum=0;
		
		for( int px_y=0; px_y<3; px_y++) {
			
		  for( int px_x=0; px_x<3; px_x++) {
			png_bytep row_temp= file_data->row_pointers[y+px_y] ;
            png_bytep px_temp= &( row_temp[( x+px_x) * 4] );
			sum+=px_temp[n] ;
		  }
		}
		px[n] =( png_uint_16)( ( int)( sum/9));
	  }
    }
  }
}


void filtr( IMAGE_DATA* file_data) {

  int matrix[9] ;
  printf( "Enter 9 int of your filtr\n");
  for( int n= 0; n< 9; n++) {
	scanf( "%d", matrix+n);
  }
	
  for( int y= 0; y< file_data->height-3; y++) {
    png_bytep row= file_data->row_pointers[y] ;
	
    for( int x= 0; x< file_data->width-3; x++) {
      png_bytep px= &( row[( x) * 4] );
	  int arr[3] ;
	  
	  for( int n=0; n<3; n++) {
        arr[n] =matrix[3*n] *px[0] +matrix[3*n+1] *px[1] +matrix[3*n+2] *px[2] ;
	    if( arr[n] > 255) arr[n] =255;
	  }
	  
	  px[0] =( png_uint_16)( arr[0] );
	  px[1] =( png_uint_16)( arr[1] );
	  px[2] =( png_uint_16)( arr[2] );
    }
  }
}

void depth( IMAGE_DATA* file_data) {
  for( int y= 0; y< file_data->height-3; y++) {
    png_bytep row= file_data->row_pointers[y] ;
	
    for( int x= 0; x< file_data->width-3; x++) {
      png_bytep px= &( row[( x) * 4] );
	  int matrix[9] =   {1000,0,0,
						0,1000,0,
						0,0,1000};
						
	  int arr[3] ;
	  long sum;
	  for( int n=0; n<3; n++) {
		sum=0;
		
		for( int px_y=0; px_y<3; px_y++) {
			
		  for( int px_x=0; px_x<3; px_x++) {
			png_bytep row_temp= file_data->row_pointers[y+px_y] ;
            png_bytep px_temp= &( row_temp[( x+px_x) * 4] );
			sum+=px_temp[n] ;
		  }
		}
        arr[n] =matrix[3*n] *px[0] +matrix[3*n+1] *px[1] +matrix[3*n+2] *px[2] ;
		arr[n] /=sum;
	    if( arr[n] > 255) arr[n] =255;
	  }
	  
	  px[0] =( png_uint_16)( arr[0] );
	  px[1] =( png_uint_16)( arr[1] );
	  px[2] =( png_uint_16)( arr[2] );
    }
  }
}

void delate_one_of_rgb( IMAGE_DATA* file_data) {

  int color;
  printf( "Enter one int of color you want to delate( red=0, green=1, blue=2): ");
  scanf( "%d", &color);
  
  for( int y= 0; y< file_data->height-3; y++) {
    png_bytep row= file_data->row_pointers[y] ;
	
    for( int x= 0; x< file_data->width-3; x++) {
      png_bytep px= &( row[( x) * 4] );
	  px[color] =0;
	}
  }
}

int** histogram( IMAGE_DATA* file_data) {
  //init
  png_bytep px= &( file_data->row_pointers[0] [0] );
  int** histogram_arr;
  histogram_arr= malloc( 3*sizeof( int*));
  int max[3] ;
  
  for( int n=0; n< 3; n+=1) {
	max[n] = pow( 2, sizeof( px));
	printf( "%d", max[n] );
	printf( "%lf\n", pow( 2, sizeof( px)));
    histogram_arr[n] = malloc( max[n] *sizeof( int));
	
	for( int m= 0; m< max[n] ; m+=1) {
		histogram_arr[n] [m] = 0;
	}
  }
  //add data
  for( int y= 0; y< file_data->height-3; y++) {
    png_bytep row= file_data->row_pointers[y] ;
	
    for( int x= 0; x< file_data->width-3; x++) {
      png_bytep px= &( row[( x) * 4] );
	  
	  for( int n= 0; n< 3; n+=1) {
		  histogram_arr[n] [px[n] ] +=1;
	  }
	}
  }
  
  //end
  return histogram_arr;
}
