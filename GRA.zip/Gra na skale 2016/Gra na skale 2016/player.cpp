#include "player.h"
#include <math.h>
#include <SFML\Window\Mouse.hpp>
#include <string>
#include <fstream>

player::player(sf::Vector2i& position, std::fstream&file, sf::Texture* textures , map* map_handle)
{
	file >> nick;
	file >> hp;
	file >> mp;
	file >> race;
	for (int n = 0; n < 8; n++) file >> status[n];
	for (int n = 0; n < 64; n++) file >> skills[n];
	for (int n = 0; n < 64; n++) file >> backpack[n];

	for (int n = 0; n < 12; n++) {
		atributes[n] = race;
		for (int m = 0; m < 8; m++)
			atributes[n] += atr[m][n]*status[m];

	}
	hp = atributes[0] * 30;
	mp = atributes[1] * 20;


	this->map_handle = map_handle;
	std::cout << "Create player\n";
	texture.loadFromFile("player.png");
	sprite.setPosition(sf::Vector2f(position));
	sprite.setTexture(texture);

	text_show.width = texture.getSize().x/3;
	text_show.height = texture.getSize().y / 3;
	text_show.left = text_show.width;
	text_show.top = text_show.height;
	sprite.setTextureRect(text_show);


	sprite.setOrigin(text_show.width / 2, text_show.height / 2);
	checks_set(sprite.getOrigin());

	move.x = 0;
	move.y = 0;
	arial.loadFromFile("arial.ttf");
	this->text.setFont(arial);
	this->text.setCharacterSize(24);

	action_add(&player::key);

	action_add(&player::gravity);
}

player::~player()
{
	std::cout << "Delete player\n";
	action_delall();
	delete actions;
}

void player::action_do()
{
	do_it = actions;
	while (do_it != NULL) {
		do_it = do_it->next;
		if (do_it != NULL && do_it->it != NULL)(this->*(do_it->it))();
	}
}

bool player::action_is(pntr it)
{
	action* temp = actions->next;

	while (temp != NULL) {
		if (temp->it == it) return true;
		temp = temp->next;
	}
	return false;
}

void player::action_add(pntr it)
{
	action* new_one = actions;

	while (new_one->it != it && new_one->next != NULL) new_one = new_one->next;
	if (new_one->it == it) return;
	new_one->next = new action;
	new_one->next->it = it;
	new_one->next->back = new_one;
}

void player::action_del(pntr it)
{
	action* del_one = actions->next;
	while (del_one != NULL && del_one->it != it) del_one = del_one->next;
	if (del_one != NULL) {
		do_it = del_one->back;
		del_one->back->next = del_one->next;
		if (del_one->next != NULL)del_one->next->back = del_one->back;
		delete del_one;
	}
	else std::cout << "problem z usunieciem akcji\n";
}

void player::action_delall()
{

	action* it = actions;
	while (it->next != NULL) it = it->next;
	it = it->back;
	while (it != NULL) {
		delete it->next;
		it = it->back;
	}
}


void player::render()
{
}

void player::draw(sf::RenderTarget& target, sf::RenderStates states) const
{
	target.draw(sprite);
	target.draw(weapon);
	target.draw(text);
	
}


void player::update(sf::Time time, sf::Vector2i mouse)
{
	this->time = time;
	sf::Vector2f rect = sprite.getPosition();
	for (int n = 0; n < 8; n++)
		detect[n].b = map_handle->checkspot(rect, sf::Vector2f(detect[n].v));



	makemove();

	action_do();

	//choosing sprite from 9 pose according to move
	{
		// x 
		text_show.left = text_show.width;
		if (move.x > 0.1)text_show.left += text_show.width;
		else if (move.x < -0.1)text_show.left -= text_show.width;

		// y
		text_show.top = text_show.height;
		if (move.y > 0.1)text_show.top += text_show.height;
		else if (move.y < -0.1)text_show.top -= text_show.height;

		// apply
		sprite.setTextureRect(text_show);
	}
	
	//check collision and change move vec
	map_handle->collision(sprite.getGlobalBounds(), move);

	// move
	sprite.move(move);


	// update child class's
	weapon.update(sprite.getPosition(), mouse + map_handle->position());
	text.setPosition(sf::Vector2f(map_handle->position()));

}

void player::setfly(bool it)
{
	switch (it + 2*flying)
	{
	case 1:
		action_del(&player::gravity);
		action_add(&player::fly);
		break;
	case 2:
		action_del(&player::fly);
		action_add(&player::gravity);
		break;
	default:
		break;
	}
	flying = it;

}


void player::checks_set(sf::Vector2f orgin){

	detect[0].v.x += orgin.x;
	detect[0].v.y -=  orgin.y + distance;

	detect[1].v.x += orgin.x + distance;
	detect[1].v.y -= orgin.y +0.1;

	detect[2].v.x += orgin.x + distance;
	detect[2].v.y += orgin.y;

	detect[3].v.x += orgin.x;
	detect[3].v.y += orgin.y + distance;

	detect[4].v.x -= orgin.x;
	detect[4].v.y += orgin.y + distance;

	detect[5].v.x -= orgin.x + distance;
	detect[5].v.y += orgin.y;

	detect[6].v.x -= orgin.x + distance;
	detect[6].v.y -= orgin.y + 0.1;

	detect[7].v.x -= orgin.x;
	detect[7].v.y -= orgin.y + distance;

}



void player::makemove()
{
	

	if (acc.x == 0) move.x -= move.x / 5;
	else move.x += acc.x*time.asSeconds();
	
	if (acc.y == 0) move.y -= move.y / 10;
	else move.y += acc.y*time.asSeconds();

	acc.x = 0;
	acc.y = 0;


	float max = (speed);
	// check max speed
	if (move.x !=0 || move.y!=0)
	{
		if (move.x > max) move.x = max;
		if (move.x < 0 - max) move.x = 0 - max;

		if (move.y > speed) move.y = speed;
		if (move.y < 0 - max) move.y = 0 - max;

	}
}



void player::key_set(sf::Keyboard::Key* it)
{
	for (int i = 0; i < 8; i++)
		Keys[i].k = it[i];
}



void player::gravity()
{
	if (!(detect[3].b || detect[4].b)) {
		move += map_handle->gravity();
	}
	else {
		if (Keys[3].b) acc.y += 0.5f;
		if (Keys[2].b)
		{
			// restore default
			action_add(&player::jump);
			jump_up = jump_up_time;
		}

	}
}

void player::fly()
{
	if (Keys[2].b) acc.y -= 1.5;
	if (Keys[3].b) acc.y += 1.5;
}

void player::dash()
{

	bool* key_rel[4] = {&dashing[1],&dashing[0],&dashing[3],&dashing[2]};

	for (int n = 0; n < 4; n++) {

		if (Keys[n].b) {
			if (dashing[n]){
				switch (n)
				{
				case 0:
					move.x -= 100;
					break;
				case 1:
					move.x += 100;
					break;
				case 2:
					move.y -= 100;
					break;
				case 3:
					move.y += 100;
					break;
				}

			}
			else {
				dashing[n] = true;
				*key_rel[n] = false;
			}
		}
		else dashing[n] = false;
	}


}

void player::jump()
{
	float mov = dt * jump_up / 2;
	if (Keys[2].b && mov > -0.1)
	{
		move.y -= mov;


		if (jump_up > 0 /*&& !(detect[4].b || detect[3].b)*/) jump_up--;
		return;
	}
	action_del(&player::jump);
}


void player::key()
{
	for (int n = 0; n < 8; n++) {
		Keys[n].b = sf::Keyboard::isKeyPressed(Keys[n].k);
	}

	if (Keys[0].b && !detect[6].b && !detect[5].b)acc.x -= 16.;
	if (Keys[1].b && !detect[2].b && !detect[1].b)acc.x += 16.;

	if (Keys[6].b) {
		weapon.visable = !weapon.visable;
		if (speed == walk)speed = run;
		else speed = walk;
	}
}

void player::show()
{
	text.setString(nick + ":\n" +
		"move.x: " + std::to_string(move.x) + ", move.y: " + std::to_string(move.y) + "\n" +
		"c1: " + std::to_string(detect[1].b) + ", c2: " + std::to_string(detect[2].b) + "\n" +
		"c3: " + std::to_string(detect[3].b) + ", c4: " + std::to_string(detect[4].b) + "\n" +
		"c5: " + std::to_string(detect[5].b) + ", c6: " + std::to_string(detect[6].b) + "\n" +
		"c7: " + std::to_string(detect[7].b) + ", c0: " + std::to_string(detect[0].b) + "\n");

	text.setPosition(sf::Vector2f(map_handle->position()));
}

void player::center()
{
	map_handle->cameralock(sprite.getPosition()-sprite.getOrigin());

}

