#include "state_game.h"

#include "music.h"
#include "gui.h"
#include "player.h"
#include "map.h"
#include "button.h"
#include "statusbar.h"
#include <SFML\Window\Mouse.hpp>
#include <fstream>
#include "state_menu.h"


game::~game()
{
	delete mmap;
	delete mmusic;
	delete player_first;
	//delete player_second;
	delete hp;
	delete mp;
}

void game::Run()
{
	//std::cout << "enter the map name: ";
	//std::string sav_name;
	//std::cin >> sav_name;
	
	
	/*
	mmap = new map(0);
	if (!mmap->is_load()) {
		std::cout << "error while loading map,\n";
		corestate->SetState(new menu);
		return;
	}*/

	font.add("arial");

	mmusic = new music;
	mmusic->volume(0);
	mmusic->play("music.flac");


	tex.loadTexture("player", "player.png");
	tex.loadTexture("weapon", "weapon.png");
	tex.loadTexture("beam", "beam.png");
	tex.loadTexture("statusbar", "statusbar.png");
	/*
	player_first = new player(sf::Vector2i(25, 25), file, &tex.getRef("beam"), mmap);
	player_first->settitle("first");
	player_first->setfly(true);
	player_first->key_set(keys);
	player_first->weapon_get().load(&tex.getRef("weapon"), &tex.getRef("beam"));


	player_second = new player(sf::Vector2i (25,25), file, &tex.getRef("beam"), mmap);
	player_second->settitle("Karol II Kremownik");
	player_second->key_set(&(keys[8]));
	player_second->setfly(false);
	player_second->action_add(&player::show);
	player_second->action_add(&player::center);
	//player_second->action_add(&player::dash);
	player_second->weapon_get().load(&tex.getRef("weapon"), &tex.getRef("beam"));
	*/
	hp = new statusbar(&tex.getRef("statusbar"));
	hp->color(sf::Color::Red);
	mp = new statusbar(&tex.getRef("statusbar"));
	mp->color(sf::Color::Blue);
	mp->orgin(false);


	texture* gtex = g.tex();
	gtex->loadTexture("button", "test.png");

	font.add("arial");
	g.button(500, 0, "button", "option", font.get("arial"));


	//stor.push_back(player_first);
	//stor.push_back(player_second);
	Load("testy");

	clock.restart();
}

void game::Update()
{


	const sf::Vector2i mouse = sf::Mouse::getPosition(*window);
	time = clock.getElapsedTime();
	clock.restart();
	
	player_first->update(time, sf::Mouse::getPosition(*window));// sf::Mouse::getPosition(window));
	//player_second->update(time,sf::Mouse::getPosition(*window));

	mmap->update();

	hp->update(player_first->get_hp(),
		sf::Vector2f(window->getSize().x/2, window->getSize().y));
	mp->update(player_first->get_hp(),
		sf::Vector2f(window->getSize().x / 2, window->getSize().y-20));

	if (g.get(0)->collision(mouse))
		corestate->SetState(new menu);


	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
		corestate->SetState(new menu);

}

void game::draw(sf::RenderTarget& target, sf::RenderStates states) const
{
	for (auto it : stor) mmap->draw(it);
	target.draw(*mmap);
	target.draw(g);
	target.draw(*hp);
	target.draw(*mp);
}



void game::Destroy()
{
}



bool game::Load(std::string save)
{
	std::fstream file;
	file.open(save + ".sav", std::ios_base::in | std::ios_base::out | std::ios_base::binary);

	if (!file.is_open()) {
		std::cout << "Cant open save. Exiting to menu\n";
		return 0;
	}
	
	file >> Stage;
	/**/
	file >> Map;
	mmap = new map(Map);
	file >> Checkpoint;
	for (int n = 0;n < 64; n++) {
		file >> Missions[n];
	}

	player_first = new player(mmap->checkpoint(Checkpoint), file, &tex.getRef("beam"), mmap);
	player_first->key_set(&keys[8]);
	player_first->setfly(false);
	//player_first->action_add(&player::show);
	player_first->action_add(&player::center);
	player_first->weapon_get().load(&tex.getRef("weapon"), &tex.getRef("beam"));
	stor.push_back(player_first);


}