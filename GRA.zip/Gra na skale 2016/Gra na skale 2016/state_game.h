#pragma once

class player;
class map;
class statusbar;

#include "states.h"
#include "fonts.h"
#include <SFML\Window\Keyboard.hpp>


#pragma once
class game : public state_sample
{
public:

	~game();
	std::string name() { return "Game"; }

	void Run();
	void draw(sf::RenderTarget& target, sf::RenderStates states) const;
	void Update();
	void Destroy();
	music* Music(){ return mmusic; };

private:
	bool Load(std::string);


	friend class console;

	struct {
		std::string name;
		int id;
	} stages[6] = {
		{ "house", 11 },{ "cave",12 },{ "ball",13 },{ "footsteps",14 },{ "caveexit",15 },{ "fear",16 } };

	//time handler
	sf::Clock clock;
	sf::Time time;


	map* mmap;
	texture tex;
	music* mmusic;
	player* player_first;
	//player* player_second;
	statusbar* hp;
	statusbar* mp;
	fonts font;
	std::vector<sf::Drawable*>stor;

	short Stage, Map, Checkpoint;
	short Missions[64];

	sf::Keyboard::Key keys[16] = {
		sf::Keyboard::A,
		sf::Keyboard::D,
		sf::Keyboard::W,
		sf::Keyboard::S,
		sf::Keyboard::LControl,
		sf::Keyboard::LShift,
		sf::Keyboard::Q,
		sf::Keyboard::E,
		sf::Keyboard::Left,
		sf::Keyboard::Right,
		sf::Keyboard::Up,
		sf::Keyboard::Down,
		sf::Keyboard::N,
		sf::Keyboard::M,
		sf::Keyboard::J,
		sf::Keyboard::K };
};