#pragma once
#include <SFML\System\Vector2.hpp>
#include <SFML\Graphics\Rect.hpp>



class handler {

	int map_coll(sf::Vector2i pos, sf::Vector2f move);
	int collision(const sf::Vector2i&, sf::Vector2i&);
	int collision(const sf::IntRect&, const sf::IntRect&);



};