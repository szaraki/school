#pragma once

//#include "weapons.h"
#include "map.h"
#include "weapons.h"

struct checks{
	sf::Vector2i v = {0,0};
	bool b = false;
};


class player : public sf::Drawable
{
	
	typedef void(player::*pntr)();


	struct action{

		pntr it = NULL;
		action* next = NULL;
		action* back = NULL;
	};

	action* do_it;

public:
	void action_do();
	bool action_is(pntr);
	void action_add(pntr);
	void action_del(pntr);
	void action_delall();



	player(sf::Vector2i&, std::fstream&, sf::Texture*, map*);
	~player();

	void render();
	void draw(sf::RenderTarget& target, sf::RenderStates states) const;
	


	void update(sf::Time, sf::Vector2i);
	void setfly(bool);


	weapons& weapon_get() { return this->weapon; }

	const int& get_hp() {
		return hp;
	}
	void key_set(sf::Keyboard::Key* it);


	void key();
	void show();
	void center();
	void dash();
protected:



	short mission[32];// another class

	//action storage
	action* actions=new action;
	

	//colisions
	void checks_set(sf::Vector2f);
	checks detect[8]; // check moves (will replace colision_map)
	int distance = 5;

	//fly
	void fly();
	bool flying = false;

	void gravity();
	void jump();
	
	//dash
	bool dashing[4] = {0,0,0,0};

	//jump setup
	bool jumpkeysense = false; // if on when player take finger off key, jump stoped
	bool jumpdouble = false;
	const double jump_up_time = 60; // more -> longer jumper
	float f;
	float dt = 3. / jump_up_time;
	const double jump_off_time = 10; // more-> longer falling/offset
	// more grav -> less attitude    ***when grav turn off-> player dont fall***
	unsigned int jump_up = 0;
	unsigned int jump_off = 0;

	//keys
	struct  {
		sf::Keyboard::Key k = sf::Keyboard::Unknown;
		bool b = false;
	} Keys[8];

	//move
	void makemove();
	sf::Vector2f move; // speed
	sf::Vector2f acc = { 0,0 };


	int speed = 5;	//actual
	int walk = 3;	//slow
	int run = 5;	//fast

	std::string nick;
	int hp, mp, stamina;
	short race;
	short status[8];
	bool skills[64];
	short atributes[12];
	int backpack[128];

	short atr[8][12] = {
		//	  h m s r MrSr a Ma s d Md l
			{ 1,1,1,0, 0,1,0,0, 0,0,0,0, }, //vit
			{ 0,0,0,1, 1,1,0,0, 1,1,0,0, }, //dex
			{ 1,0,1,1, 0,1,0,0, 0,1,0,0, }, //end
			{ 0,0,1,1, 0,0,1,0, 1,0,0,1, }, //str
			{ 0,1,0,0, 1,0,0,1, 1,1,1,0, }, //int
			{ 1,0,1,1, 1,0,0,0, 0,1,0,0, }, //res
			{ 0,1,0,0, 1,0,0,1, 0,1,1,1, }, //fai
			{ 1,1,1,1, 1,1,1,1, 1,1,1,1, }};//unknown



	weapons weapon;
	//sfml things
	sf::Sprite sprite;
	sf::Texture texture;

	map* map_handle;
	sf::Time time;
	sf::Text text;
	std::string texts;
	sf::Font arial;
	sf::IntRect text_show;

};

