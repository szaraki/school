

class clocks
{
public:



private:



};