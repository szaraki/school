
#include "id.h"
#include "box.h"
#include "screen.h"
#include <iostream>

block::block(id* handle, sf::Vector2i size)
	: window(sf::VideoMode(size.x, size.y), "block", sf::Style::Default),
	t_core(),
	tool(&t_core)
{
	//
	this->handle = handle;
	//window settings
	window.setFramerateLimit(30);
	window.setActive(false);

	//settings sprites for collisions
	bool_tex.loadFromFile("bool.png");
	block_sprite.setScale(sf::Vector2f(10., 10.));
	for (int n = 0; n < 50; n++) {
		for (int m = 0; m < 50; m++) {
			mini[n][m].setPosition(10 * n, 10 * m);
			mini[n][m].setColor(color[0]);
			mini[n][m].setTexture(bool_tex);
		}
	}
	handle2 = new box(sf::Vector2i(70,250));
	handle2->add(&this->tool);


}

bool block::update()
{
	if (window.isOpen()) {
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				window.close();
			}
		}

		if (window.hasFocus()) render();

		if (sf::Mouse::isButtonPressed(sf::Mouse::Button::Left))
		{
			sf::Vector2i pos = sf::Mouse::getPosition(window);
			pos.x /= 10;
			pos.y /= 10;

			
			for (int n = 0; t_core.selected->coll[n].x == 0 && t_core.selected->coll[n].y == 0; n++)
			{
				int x = pos.x;// +tool.selected->coll[n].x;
				int y = pos.y;// +tool.selected->coll[n].y;
				if (x >= 0 && x < 50 &&
					y >= 0 && y < 50) {
					//if (handle->selected()->t[pos.x][pos.y]) 
						{
							handle->selected()->t[x][y] = 0;
							mini[x][y].setColor(color[1]);
						}
						render();
				}
			}

		}

		if (sf::Mouse::isButtonPressed(sf::Mouse::Button::Right))
		{
			sf::Vector2i pos = sf::Mouse::getPosition(window);
			pos.x /= 10;
			pos.y /= 10;

			if (pos.x >= 0 && pos.x < 50 &&
				pos.y >= 0 && pos.y < 50) {
				if (!handle->selected()->t[pos.x][pos.y]) {
					handle->selected()->t[pos.x][pos.y] = 1;
					mini[pos.x][pos.y].setColor(color[0]);
				}
				render();
			}
		}


		if (block_handle != handle->selected()) {
			block_handle = handle->selected();
			block_sprite.setTexture(block_handle->texture);
			for (int n = 0; n < 50; n++) {
				for (int m = 0; m < 50; m++) {
					mini[n][m].setColor(color[block_handle->t[n][m]]);
				}
			}

			render();
		}
		handle2->update();
		return true;
	}
	else return false;
}

void block::render()
{
	window.clear();
	window.draw(block_sprite);
	for (int n = 0; n < 50; n++)
		for (int m = 0; m < 50; m++)
			window.draw(mini[n][m]);
	window.display();
}