#include "tools.h"
#include <iostream>


tools::~tools()
{
	show(false);

	tool* temp = stor;
	while (temp->next != NULL) {
		tool* del = temp;
		temp = temp->next;
		delete del;
	}


}

void tools::show(bool it)
{
	this->showing = it;
}

void tools::draw(sf::RenderTarget& target, sf::RenderStates states) const
{
	tool* temp = stor;
	while (temp->next != NULL) {
		temp = temp->next;
		target.draw(temp->min.sprite, states);
		//add showing text after focus
	}
}

int tools::rect_change(sf::Vector2u it)
{
	if (it.y < 100) it.y = 100;

	
	tool* temp = stor->next;
	sf::Vector2i pos = { 5,5 };
	int y = 10;
	for (; y < it.y && temp != NULL; y+=25) {
		for (int x = 10; x + 40 < it.x && temp != NULL; x += 25, temp = temp->next) {
			temp->min.sprite.setPosition(x, y);
		}
	}

	if (y < 100)return 100;
	else return y;
}


void tools::add(std::string name, int size)
{
	tool* temp = stor;
	while (temp->next != NULL)temp = temp->next;

	//creating new tool
	temp->next = new tool;
	temp = temp->next;


	temp->core = this->core->add(name, size);


	//rest
	temp->min.texture.loadFromFile(name + "min.png");

	temp->min.sprite.setTexture(temp->min.texture);
	temp->min.text.setFont(font);
	temp->min.text.setString(name);
}
