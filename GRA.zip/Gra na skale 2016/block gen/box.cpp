#include "box.h"
#include <iostream>



box::box(sf::Vector2i window_res)
	:window(sf::VideoMode(window_res.x, window_res.y), "tools", sf::Style::Close | sf::Style::Resize),
	view(sf::FloatRect(0,0,window_res.x, window_res.y))
{

	window.setActive(false);
	window.setView(view);

	showptr = new show;
	

	line_texture.loadFromFile("line.png");
	line_texture.setRepeated(true);
}

box::~box()
{
	show* temp = showptr;
	while (temp->next != NULL) {
		temp = temp->next;
	}

	while (temp->before != NULL)
	{
		temp = temp->before;
		delete temp->next;
	}

	delete showptr;
}

void box::add(showable* it)
{
	show* temp = showptr;
	while (temp->next != NULL) temp = temp->next;
	temp->next = new show;
	temp->next->before = temp;
	temp->next->showable = it;
	it->show(true);

	temp->next->line.setTexture(line_texture);
	resized(window.getSize().x, window.getSize().y);
}

void box::add(showable* before, showable* it)
{
	show* temp = showptr;
	while (temp->next != NULL && temp->showable != before) temp = temp->next;
	temp->next = new show;
	temp->next->before = temp;
	temp->next->showable = it;
	it->show(true);

	temp->next->line.setTexture(line_texture);
	resized(window.getSize().x, window.getSize().y);
}

void box::del(showable* it)
{
	show* temp = showptr;
	while (true)
	{
		if (temp->showable == it) break;
		if (temp->next == NULL)return;
		else temp = temp->next;
	}
	//make connection
	temp->before->next == temp->next;
	temp->next->before = temp->before;

	temp->showable->show(false);
	delete temp;
}

bool box::update()
{
	sf::Event event;
	while (window.pollEvent(event))
	{
		switch (event.type){
		case sf::Event::Closed:
			return 1;

		case sf::Event::Resized:
			resized(event.size.width, event.size.height);
			break;

		default:
			break;
		}
	}



	sf::Vector2i mouse = sf::Mouse::getPosition(window);



	render();
	return 0;
}

void box::resized(unsigned int x, unsigned int y)
{
	if (x < size_min.x) x = size_min.x;
	if (y < size_min.y) y = size_min.y;
	unsigned int hight= 0;

	float scale;
	if (window.getSize().y == 0) scale = 0;
	else scale = y / window.getSize().y;


	show* temp = showptr;
	while (temp->next != NULL) {
		temp = temp->next;
		sf::Vector2u rect = temp->showable->rect_get();
		rect.x = x;
		rect.y = scale*rect.y;
		hight+=temp->showable->rect_change(rect);
		temp->line.setPosition(0,hight);
		temp->line.setTextureRect(sf::IntRect(0,0,x,5));
		std::cout << temp->line.getPosition().y;
	}

	if (hight < y) hight = y;
	view.reset(sf::FloatRect(0,0,x, hight));
	window.setSize(sf::Vector2u(x, hight));
	window.setView(view);
}

void box::render()
{
	window.clear(sf::Color(0,90,130,255));


	show* temp = showptr;
	while (temp->next != NULL) {
		temp = temp->next;
		window.draw(*temp->showable);
		window.draw(temp->line);
	}
	// dodacpasek przesuwania okien, dodawania okien
	window.display();
}