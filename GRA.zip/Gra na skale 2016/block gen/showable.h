#pragma once
#include <SFML\Graphics.hpp>

class showable : public sf::Drawable{
public:
	virtual void show(bool) {}
	virtual int rect_change(sf::Vector2u) { return -1; }
	const sf::Vector2u rect_get() { return rect; }
	virtual bool update(){ return 0; } // if is 1, we can change place

	bool showing = false;
	sf::Vector2u rect;
};