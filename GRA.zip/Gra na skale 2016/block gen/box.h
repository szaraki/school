#pragma once
#include <SFML\Graphics.hpp>
#include "showable.h"


struct show {
	showable* showable;
	sf::Sprite line;

	show* before = NULL;
	show* next = NULL;

};

class box {
public:
	box(sf::Vector2i window_res);
	~box();

	//manage tools
	void add(showable* it);
	void add(showable* before, showable* it);
	void del(showable* it);


	//main func
	bool update();

protected:
	void resized(unsigned int x,unsigned int y);
	void render();


	sf::RenderWindow window;
	sf::View view;
	sf::Vector2i size_min = {50,80};
	
	// line
	sf::Texture line_texture;

	//storage
	show* showptr;
};