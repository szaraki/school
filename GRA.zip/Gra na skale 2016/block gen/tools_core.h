#pragma once
#include <SFML\Graphics.hpp>
#include <iostream>

struct tool_core {
	std::string name;
	unsigned int size = 1;
	sf::Vector2i* coll = NULL;


	struct {
		sf::Sprite sprte;
		sf::Texture texture;
	} mouse;


	tool_core* next = NULL;
};

class tools_core {
public:

	tool_core* stor;

	tools_core() {
		stor = new tool_core;

		add("pencil", 1);
		add("pen", 3);
		selected = stor->next;

	}
	~tools_core() {
		delete stor;


	}


	tool_core* add(std::string name, int size){

		tool_core* temp = stor;
		while (temp->next != NULL)temp = temp->next;

		temp->next = new tool_core;
		temp = temp->next;
		std::cout << "Loading:" << name << "\n";
		temp->name = name;
		temp->size = size;
		temp->coll = new sf::Vector2i[size*size];
		for (int n = size - 1; n >= 0; n--)
			for (int m = size - 1; m >= 0; m--) {
				int t = size*n + m;
				temp->coll[t].x = size-1-n;
				temp->coll[t].y = size-1-m;
			}
		for (int i = 0; i < size*size; i++){
			std::cout << "x:" << temp->coll[i].x
				<< "\ny:" << temp->coll[i].y << "\n";
		}
		return temp;

	}

	tool_core* selected;

private:
};