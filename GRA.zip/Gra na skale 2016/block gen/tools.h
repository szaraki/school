#pragma once
#include "showable.h"
#include "tools_core.h"

struct tool {
	tool_core* core;
	
	struct {
		sf::Texture texture;	// textures 20:20
		sf::Sprite sprite;
		sf::Text text;
	} min;
	
	tool* next = NULL;
};

class tools : public showable ,protected tools_core{
public:
	tools(tools_core* core) {
		this->core = core;

		tool* tempp = stor->next;
		tool_core* temp = core->stor->next;
		while (temp != NULL) {
			tempp = new tool;
			tempp->core = temp;

			tempp->min.texture.loadFromFile(temp->name + "min.png");
			std::cout << temp->name + "min.png";
			tempp->min.sprite.setTexture(tempp->min.texture);
			tempp->min.text.setFont(font);
			tempp->min.text.setString(temp->name);
			temp = temp->next;
			tempp = tempp->next;
		}
	}
	~tools();

	void add(std::string name, int size);
	void show(bool);
	int rect_change(sf::Vector2u);
	void draw(sf::RenderTarget& target, sf::RenderStates states) const;

	tool* selected;
private:


	sf::Font font;
	tool* stor = new tool;

	tools_core* core;
};




