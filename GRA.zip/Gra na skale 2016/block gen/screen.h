#pragma once
#include <SFML\Graphics.hpp>
#include <SFML\System\Thread.hpp>
#include "tools_core.h"
#include "tools.h"
class id;
class box;

class block {
public:
	block(id* handle, sf::Vector2i size = { 500,500 });
	bool update();


	void render();
	bool isOpen() { return window.isOpen(); }

protected:
	sf::Color color[2] = { sf::Color(0, 0, 0, 10), sf::Color(sf::Color::White)};
	sf::Sprite mini[50][50];

	sf::Sprite block_sprite;
	id_block* block_handle = NULL;
	sf::Texture bool_tex;

	id* handle;

	tools_core t_core;
	tools tool;

	box* handle2;

	sf::RenderWindow window;
};