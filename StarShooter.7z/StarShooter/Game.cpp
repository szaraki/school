#include <SFML/Graphics.hpp>
#include <iostream>


bool gameloop = false; // game loop / while funtion doing gameloop - bool = true
int gamepause;
int stage;
int newstage;
int newstagemax;
int spawn[64];
float maploop = 1200;

// Players
int plgif = 0;
int plspd = 5;  // amount of player speed per 1 second
float plmv[4];	//0- ox move/1- oy move
int	pldata[4];	//0- beamtype/1- beamspawnloop
int plbmcost[2];//0- single shoot/1- triple shoot

// Enemies

bool	enspawn = false;
int		encor[64][3];		//0- type/1- beamspawnloop/2- gif loop(0- no animated)
int		enmv[64][3];		//0- ox move/1- oy move/2 moveloop
int		enmvtype[4][2][32];	//[]type[]axis[]loop; 
int		entypedata[6][3];	//[]type/0 beamtype/1- wight/2- high/

//Beams

bool	bmspawn = false;
int		bmcor[128][2];		//0- type/1- gif loop(0- no animated)
int		bmmv[128][3];		//0- ox move/1- oy move/2 moveloop
int		bmmvtype[4][2][32];	//[]type[]axis[]loop; 
int		bmtypedata[4][3];	//[]type/0- wight/0- high/

//Score

int Score = 0;
int BestScore = 0;
int MainScore = 0;

//Graphic


sf::Sprite map;
sf::Texture gamemap;

sf::Sprite bg;
sf::Texture background;

sf::Sprite pl;
sf::Texture player;

sf::Sprite en[64];
sf::Texture enemy[6];

sf::Sprite bm[128];
sf::Texture beam[4];

void SpawnBeam(int type, int left, int top, int spdx, int spdy)
{
	for (int n = 0; n<128; n++)
	{
		if (bmcor[n][0] == 0)
		{
			bmcor[n][0] = type;
			bm[n].setPosition(left, top);
			bmmv[n][0] = spdx;
			bmmv[n][1] = spdy;
			MainScore = MainScore - plbmcost[0];
			n = 128;
		}
	}
}

void SpawnEnemy()
{
	for (int n = 0; n < 64; n++)
	{
		if (encor[n][0] == 0)
		{
			encor[n][0] = 1;
			en[n].setPosition(0, 0);
			enmv[n][0] = 0;
			enmv[n][1] = 10;
			n = 64;
		}
	}
}

void LoadGame()
{
	for (int n = 0; n < 128; n++)
	{
		bmcor[n][0] = 0;

	}
	for (int n = 0; n < 64; n++)
	{
		encor[n][0] = 0;
	}
	background.loadFromFile("bggame.png", sf::IntRect(0, 0, 850, 850));
	background.setSmooth(true);

	player.loadFromFile("player.png", sf::IntRect(0, 0, 50, 50));
	player.setSmooth(true);

	enemy[0].loadFromFile("monster1.png", sf::IntRect(0, 0, 50, 50));
	enemy[0].setSmooth(true);

	enemy[1].loadFromFile("monster2.png", sf::IntRect(0, 0, 50, 50));
	enemy[1].setSmooth(true);

	enemy[2].loadFromFile("monster3.png", sf::IntRect(0, 0, 50, 50));
	enemy[2].setSmooth(true);

	beam[0].loadFromFile("beam1.png", sf::IntRect(0, 0, 12, 20));
	beam[0].setSmooth(true);

	beam[1].loadFromFile("beam2.png", sf::IntRect(0, 0, 20, 20));
	beam[1].setSmooth(true);


	gamemap.loadFromFile("gamemap.png", sf::IntRect(0, 0, 600, 1800));
	gamemap.setSmooth(true);

	map.setPosition(171, 151);

	bg.setTextureRect(sf::IntRect(0, 0, 850, 850));
	bg.setTexture(background);

	pl.setTextureRect(sf::IntRect(0, 0, 50, 50));
	pl.setTexture(player);

}


int test()
{
	sf::Text text;
	sf::Font font;
	font.loadFromFile("arial.ttf");
	text.setFont(font);
	text.setCharacterSize(24);

	sf::RenderWindow window(sf::VideoMode(850, 850, 32), "1st window");
	window.setFramerateLimit(60);


	window.clear(sf::Color(255, 0, 0));

	int fps = 1;
	int showfps = 0;


	sf::Clock clock;
	sf::Clock clockmv;
	int clockmove;
	sf::Time  time = sf::seconds(1);

	LoadGame();



	while (window.isOpen())
	{

		fps++;
		if (fps == 60)
		{
			showfps = (int)60 / clock.getElapsedTime().asSeconds();
			fps = 0;
			clock.restart();
		}
		text.setString(std::to_string(showfps));

		//clock

		clockmove = clockmv.getElapsedTime().asMilliseconds();
		clockmv.restart();

		// Window Event

		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		// Input

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			plmv[1] -= 1;
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
			plmv[1] -= 1;

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
			plmv[1] += 1;
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
			plmv[1] += 1;

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
			plmv[0] -= 1;
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
			plmv[0] -= 1;

		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
			plmv[0] += 1;
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
			plmv[0] += 1;

		plmv[0] *= clockmove*0.5;
		plmv[1] *= clockmove*0.5;
		//Moving Map

		map.setTextureRect(sf::IntRect(0, (int)maploop, 600, 600));
		map.setTexture(gamemap);

		maploop -= 0.05*clockmove;
		if (maploop <= 0)
			maploop = 1200;

		//Player Move

		pl.move(plmv[0], plmv[1]);

		plmv[0] = 0;
		plmv[1] = 0;

		//Window Draw

		window.clear(sf::Color(255, 0, 0));

		window.draw(bg);
		window.draw(map);

		window.draw(pl);
		window.draw(text);
		window.display();
	}
}