#include "main_menu.h"
#include "main_settings.h"

void main_settings::Initialize(sf::RenderWindow* window)
{
	this->font = new sf::Font();
	this->font->loadFromFile("font.ttf");

	this->title = new sf::Text("Settings", *this->font, 128U);
	this->title->setOrigin(this->title->getGlobalBounds().width / 2, this->title->getGlobalBounds().height / 2);
	this->title->setPosition(window->getSize().x / 3, window->getSize().y / 10);

	this->play = new sf::Text("option", *this->font, 64U);
	this->play->setOrigin(this->play->getGlobalBounds().width / 2, this->play->getGlobalBounds().height / 2);
	this->play->setPosition(window->getSize().x / 4, window->getSize().y / 3);

	this->settings = new sf::Text("option", *this->font, 64U);
	this->settings->setOrigin(this->settings->getGlobalBounds().width / 2, this->settings->getGlobalBounds().height / 2);
	this->settings->setPosition(window->getSize().x / 4, window->getSize().y / 2);

	this->quit = new sf::Text("option", *this->font, 64U);
	this->quit->setOrigin(this->quit->getGlobalBounds().width / 2, this->quit->getGlobalBounds().height / 2);
	this->quit->setPosition(window->getSize().x / 4, window->getSize().y / 1.5);
}
void main_settings::Update(sf::RenderWindow* window)
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Escape))
	{
		coreState.SetState(new main_menu());
	}
}
void main_settings::Render(sf::RenderWindow* window)
{
	window->draw(*this->title);
	window->draw(*this->play);
	window->draw(*this->settings);
	window->draw(*this->quit);
}
void main_settings::Destroy(sf::RenderWindow* window)
{
	delete this->font;
	delete this->title;
	delete this->play;
	delete this->settings;
	delete this->quit;
}