#pragma once

#include "game_state.h"

class main_game : public tiny_state
{
public:
	void Initialize(sf::RenderWindow* window);
	void Update(sf::RenderWindow* window);
	void Render(sf::RenderWindow* window);
	void Destroy(sf::RenderWindow* window);


private:

	int fps;
	int showfps;

	float maploop;


	// Players
	int plgif = 0;
	int plspd = 5;  // amount of player speed per 1 second
	float plmv[4];	//0- ox move/1- oy move
	int	pldata[4];	//0- beamtype/1- beamspawnloop
	int plbmcost[2];//0- single shoot/1- triple shoot

	int			clockmove;
	sf::Clock*	clock;
	sf::Clock*	clockmv;
	sf::Time*	time;

	sf::Sprite* map;
	sf::Texture* gamemap;

	sf::Sprite* bg;
	sf::Texture* background;

	sf::Sprite* pl;
	sf::Texture* player;

	sf::Sprite* en[64];
	sf::Texture* enemy[6];

	sf::Sprite* bm[128];
	sf::Texture* beam[4];
	sf::Text* text;
	sf::Font* font;
};