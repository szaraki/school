#include "main_game.h"
#include "main_menu.h"

void main_game::Initialize(sf::RenderWindow* window)
{

	window->setFramerateLimit(600);
	this->background = new sf::Texture();
	this->background->loadFromFile("bggame.png");
	this->background->setSmooth(true);

	this->player = new sf::Texture();
	this->player->loadFromFile("player.png");
	this->player->setSmooth(true);

	this->gamemap = new sf::Texture();
	this->gamemap->loadFromFile("gamemap.png");
	this->gamemap->setSmooth(true);

	this->bg = new sf::Sprite();
	this->bg->setTextureRect(sf::IntRect(0, 0, 850, 850));
	this->bg->setTexture(*this->background);

	this->map = new sf::Sprite();
	this->map->setPosition(171, 151);

	this->pl = new sf::Sprite();
	this->pl->setTexture(*this->player);
	this->pl->setOrigin(25,25);

	this->showfps = 0;
	this->fps = 1;
	this->maploop = 1200;
	this->font = new sf::Font();
	this->font->loadFromFile("font.ttf");
	this->text = new sf::Text();
	this->text->setFont(*this->font);



	this->clockmv = new sf::Clock();
	this->clockmv->restart();
	this->clock = new sf::Clock();
	this->clock->restart();

}
void main_game::Update(sf::RenderWindow* window)
{

	//show fps on screen

	if (fps == 60)
	{
		showfps = (int)60 / this->clock->getElapsedTime().asSeconds();
		fps = 0;
		this->clock->restart();
	}
	fps++;

	this->text->setString("fps: " + std::to_string(showfps));

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Escape))
	{
		coreState.SetState(new main_menu());
	}

	//clock

	clockmove = this->clockmv->getElapsedTime().asMilliseconds();
	this->clockmv->restart();

	// Input

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) || sf::Keyboard::isKeyPressed(sf::Keyboard::W))
		plmv[1] -= 1;

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) || sf::Keyboard::isKeyPressed(sf::Keyboard::S))
		plmv[1] += 1;

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) || sf::Keyboard::isKeyPressed(sf::Keyboard::A))
		plmv[0] -= 1;

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) || sf::Keyboard::isKeyPressed(sf::Keyboard::D))
		plmv[0] += 1;

	plmv[0] *= clockmove*0.5f;
	plmv[1] *= clockmove*0.5f;

	//Player move

	this->pl->move(plmv[0], plmv[1]);

	plmv[0] = 0;
	plmv[1] = 0;

	//Player can't go outside 
	sf::Vector2f plvec = this->pl->getPosition();
	if (plvec.x + 25 + plmv[0] > 600 + 171) plmv[0] = 0, this->pl->setPosition(171+600-25, plvec.y);
	if (plvec.x - 25 + plmv[0] < 171) plmv[0] = 0, this->pl->setPosition(171+25, plvec.y);
	
	plvec = this->pl->getPosition();
	if (plvec.y - 25 + plmv[1] < 151) plmv[1] = 0, this->pl->setPosition(plvec.x, 151+25);
	if (plvec.y + 25 + plmv[1] > 600 + 151) plmv[1] = 0, this->pl->setPosition(plvec.x, 151+600 -25);

	// Update map
	this->map->setTextureRect(sf::IntRect(0, maploop, 600, 600));
	this->map->setTexture(*this->gamemap);
	
	maploop -= 0.05f*clockmove;
	if (maploop <= 0)
		maploop = 1200;
	//this->text->setString(std::to_string(this->maploop));



}
void main_game::Render(sf::RenderWindow* window)
{
	window->draw(*this->bg);
	window->draw(*this->map);
	window->draw(*this->pl);
	window->draw(*this->text);
}
void main_game::Destroy(sf::RenderWindow* window)
{
	delete this->map;
	delete this->gamemap;
	delete this->bg;
	delete this->background;
	delete this->pl;
	delete this->player;
	for (int n = 0; n > 64; n++)
	{
		delete this->en[n];
	}
	for (int n = 0; n > 6; n++)
	{
		delete this->enemy[n];
	}

	for (int n = 0; n > 64; n++)
	{
		delete this->bm[n];
	}

	for (int n = 0; n > 4; n++)
	{
		delete this->beam[n];
	}
}
